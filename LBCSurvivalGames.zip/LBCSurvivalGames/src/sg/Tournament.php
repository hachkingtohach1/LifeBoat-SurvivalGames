<?php

namespace sg;

use sg\data\PluginData;
use sg\SurvivalGames;
use sg\player\SGPlayer;
use Kits\KitData;
use LbCore\LbCore;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\LaunchSound;
use pocketmine\level\sound\PopSound;
use pocketmine\level\sound\BatSound;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

/**
 * Class Tournament describes common game logic on arena
 * creates object for each arena
 */
class Tournament {
	/* @var SurvivalGames */
	private $plugin;
	/*@var bool*/
	private $started = false;
	/*@var bool*/
	private $invincible = false;
	/*@var bool*/
	private $deathMatch = false;
	/*@var Server*/
	private $level;
	/*@var int - id of current tournament*/
	private $id;
	/*@var int*/
	private $mapId;
	/*@var array*/
	private $mapData;
	/*@var array*/
	private $players = array();
	/*@var array*/
	private $onSpawnPoint = array();
	/*@var int*/
	private $tick = 0;
	/*@var string*/
	private $humanReadableTime = "3:00"; //max countdown time
	/*@var array*/
	private $filledChests = array();
	/*@var array*/
	private $kills = array();
	/*@var array*/
	private $teams = array();
	/*@var array*/
	private static $teamColors = array(
		'red',
		'blue',
		'green'
	);
	
	const MAX_NON_VIP_PLAYER_COUNT = 20;
	const MAX_PLAYER_COUNT = 24;
	const PEDESTALS_COUNT = 24;
	const MAX_MAP_INDEX = 22;
	const MATCH_START_IN_SECONDS = 180;
	const DEATHMATCH_START_IN_SECONDS = 660;
	const MATCH_FINAL_IN_SECONDS = 900;
	const MAP_OF_JUSTICE_ID = 1;

	/**
	 * construct of tournament class, 
	 * creates tournament arena and sign for it
	 * 
	 * @param SurvivalGames $plugin
	 */
	public function __construct(SurvivalGames $plugin) {
		$this->plugin = $plugin;
		$this->level = $this->plugin->getServer()->getDefaultLevel();
		//prepare tournament id
		for ($i = 1; $i <= 5; $i++) {
			if (!isset($this->plugin->tournaments[$i])) {
				$this->id = $i;
				break;
			}
		}
		$this->setDefaultTeams();

		if ($this->id === 1) {
			$this->initSigns();
		}
		$this->updateMapData();
		$this->updateSign();
	}
	
	/**
	 * @return bool
	 */
	public function isStarted() {
		return $this->started;
	}
	
	/**
	 * @return bool
	 */
	public function isInvincible() {
		return $this->invincible;
	}
	
	/**
	 * @return bool
	 */
	public function isDeathMatch() {
		return $this->deathMatch;
	}

	/**
	 * @return int
	 */
	public function getPlayerCount() {
		return count($this->players);
	}
	
	/**
	 * @return array
	 */
	public function getPlayers() {
		return $this->players;
	}

	/**
	 * create default teams array
	 */
	private function setDefaultTeams() {
		if ($this->plugin->useTeams) {
			$this->teams = array();
			foreach (self::$teamColors as $color) {
				$this->teams[$color] = array();
			}
		}
	}
	
	/**
	 * @return array
	 */
	public function getTeams() {
		return $this->teams;
	}
	
	/**
	 * @return string
	 */
	public function getCountdownTime() {
		return $this->humanReadableTime;
	}

	/**
	 * choose map and save it like last map used
	 */
	private function updateMapData() {
		$this->mapId = $this->plugin->getLastMapUsed();
		$this->mapData = PluginData::$mapData[$this->mapId];
		$this->plugin->setLastMapUsed($this->mapId + 1);
		if ($this->plugin->getLastMapUsed() >= self::MAX_MAP_INDEX) {
			$this->plugin->setLastMapUsed(1);
		}
	}

	/**
	 * declare items for chests and randomly fill slots with them
	 * set opened chest as empty
	 * 
	 * @param $chest
	 * @param bool $isDouble
	 */
	public function fillChest($chest, bool $isDouble) {
		$block = $chest->getInventory()->getHolder();
		//check for empty chest
		if (in_array(
				$block->getX() . "," . $block->getY() . "," . $block->getZ(), 
				$this->filledChests)) {
			return false;
		} else {
			$this->filledChests[] = $block->getX() . "," . $block->getY() . "," . $block->getZ();
		}
		$currentChest = array();
		$chest->getInventory()->clearAll();
		//declare allowed items
		$items = PluginData::$chestItems;
		//check if it's double or simple chest
		$slotsTotal = rand(4, 13);
		if ($isDouble) {
			$slotsTotal = rand(8, 24);
		}
		// prospector kit part
		$player = $chest->getPlayer();
		if ($player->haveKit(KitData::PROSPECTOR)) {			
			$slotsTotal++;
		}
		//fill slots
		$chestInventory = $chest->getInventory();
		for ($d = 0; $d <= $slotsTotal; $d++) {
			$r = rand(1, 1000);
			$done = false;
			//give one more chance to armor
			if ($r < 718 && (rand(1, 3) === 2)) {
				$r = rand(718, 1000);
			}
			foreach ($items as $item) {
				if ($done === false &&
						($r < $item[1]) &&
						!in_array($item[0], $currentChest)) {
					$currentChest[] = $item[0];
					$done = true;
					$slotIndex = $isDouble ? rand(0, 40) : rand(0, 26);
					$count = $item[2] ? rand(1, 3) : 1;//earlier it was random from 3 to 7
					// explorer kit part
					if ($player->haveKit(KitData::EXPLORER) &&
							count($chestInventory->getContents()) < $slotsTotal / 2) {
						// if item is stackable
						if ($item[2]) {
							// increase number of items in 2
							$count *= 2;
						} else {
							// else clone item
							$chestInventory->addItem(Item::get($item[0], 0, $count));
						}
					}
					// end explorer kit part
					
					$chestInventory->setItem($slotIndex, Item::get($item[0], 0, $count));
				}
			}
		}
	}

	/**
	 * calls when tournament restart, removes all players and chunks,
	 * clear tournament data
	 */
	private function restart() {
		$this->broadcastMessageLocalized("MATCH_RESTARTING");
		$this->pushPlayersToLobby();
		$this->updateMapData();
		$this->setDefaultTournamentData();		
		$this->updateSign();//update sign as joinable again
	}

	/**
	 * teleport players to lobby, 
	 * remove them from tournament object
	 */
	private function pushPlayersToLobby() {
		foreach ($this->players as $player) {
			$player->teleport($this->level->getSpawnLocation());
			$this->removePlayer($player, true);
            $player->setStateInLobby();
			$player->updateTournamentId(false);
		}
	}

	/**
	 * reset all tournament data on restart
	 */
	private function setDefaultTournamentData() {
		$this->invincible = false;
		$this->deathMatch = false;
		$this->tick = 0;
		$this->humanReadableTime = "3:00";
		$this->onSpawnPoint = array();
		$this->players = array();
		$this->kills = array();
		$this->filledChests = array();
		$this->started = false;
		$this->setDefaultTeams();
	}

	/**
	 * calls to inform player about current arena countdown
	 */
	private function sayTime() {
		foreach ($this->players as $player) {
			LbCore::getInstance()->alerts->postponeMessage($player);
			break;
		}
		$this->broadcastMessageLocalized("STARTING_IN", array($this->humanReadableTime));
	}

	/**
	 * Calls when countdown is finished and fighting start
	 * update player's data, send start messages, update tournament data
	 */
	private function start() {
		$this->humanReadableTime = "0:00";
		foreach ($this->players as $player) {
			$player->setFoodEnabled(true);
			$player->setStateInGame($this->id);
            $player->setInDeathmatch(false);
			$player->sendLocalizedPopup("TOURNAMENT_START");
			$sound = new LaunchSound($player->getPosition(), 0);
			$this->level->addSound($sound, [$player]);
		}
		$this->sendStartInfo();
		$this->started = true;
		$this->invincible = true;
		$this->updateSign();
		if (!$this->plugin->testing) {
			$this->won();//also check if we have a winner
		}
	}

	/**
	 * Send message about tournament start, map creator, map name, invincibility
	 */
	private function sendStartInfo() {
		$this->broadcastMessage("§9> --------------------------------");
		$this->broadcastMessageLocalized("TOURNAMENT_START");
		if ($this->mapData['author'] !== 'unknown') {
			$this->broadcastMessageLocalized("USING_MAP_CREATOR", array(
				PluginData::$mapNames[$this->mapId],
				$this->mapData['author']
			));
		} else {
			$this->broadcastMessageLocalized("USING_MAP", array(PluginData::$mapNames[$this->mapId]));
		}
		$this->broadcastMessageLocalized("INVINCIBILITY_30");
		$this->broadcastMessage("§9> --------------------------------");
	}

	/**
	 * Calls for countdown on arena and do smth by tick values
	 * first 3 minutes are countdown, 
	 * then 8 minutes playing on arena, 
	 * then 4 minutes of deathmatch,
	 * then restart
	 */
	public function tick() {
		$this->tick++;
		switch ($this->tick) {
			case 15:
			case 30:
			case 45:
			case 60:
			case 75:
			case 90:
			case 105:
			case 120:
			case 135:
			case 150:
			case 165:
				$this->updateCountdownTime();
				break;
			case 175:
			case 176:
			case 177:
			case 178:
			case 179:
				$this->almostStartNotify();
				break;
			case 180:
				$this->start();
				break;
			case 195:
				$this->almostFinishInvincibility();
				break;
			case 210:
				$this->finishInvincibility();
				break;
			case 240:
			case 300:
			case 360:
				$this->deathMatchSoonNotify();
				break;
			case 420:
				$this->broadcastMessageLocalized("CHEST_REFILL");
				$this->filledChests = array();//reset array of empty chests
			case 480:
			case 540:
			case 600:
				$this->deathMatchSoonNotify();
				break;
			case 655:
				foreach ($this->players as $player) {
					LbCore::getInstance()->alerts->postponeMessage($player);
					break;
				}
			case 656:
			case 657:
			case 658:
			case 659:
				$this->deathMatchAlmostStartNotify();
				break;
			case 660:
				$this->startDeathmatch();
				break;
			case 720:
			case 780:
			case 840:
				$this->deathMatchEndSoonNotify();
				break;
			case 900:
				foreach ($this->players as $player) {
					LbCore::getInstance()->alerts->postponeMessage($player);
					break;
				}
				$this->restart();
				break;
		}
	}

	/**
	 * say time left to start game by current tick
	 */
	private function updateCountdownTime() {
		$timeLeft = self::MATCH_START_IN_SECONDS - $this->tick;
		$minutesLeft = floor($timeLeft/60);
		$secondsLeft = str_pad($timeLeft%60, 2, "0");
		$this->humanReadableTime = $minutesLeft . ":" . $secondsLeft;
		if ($this->tick % 10 == 0) {
			$this->sayTime();
		}
	}

	/**
	 * calls in 5 seconds to start, send messages and sounds to players
	 */
	private function almostStartNotify() {
		$secondsLeft = self::MATCH_START_IN_SECONDS - $this->tick;
		foreach ($this->players as $player) {
			if ($player instanceof SGPlayer) {
				$player->sendLocalizedPopup("STARTING", array($secondsLeft));
				$sound = new ClickSound($player->getPosition(), 2);
				$this->level->addSound($sound, [$player]);
			}
		}
	}
	
	/**
	 * inform about 15 seconds of invincibility left
	 */
	private function almostFinishInvincibility() {
		$this->broadcastMessageLocalized("INVINCIBILITY_15");
		foreach ($this->players as $player) {
			if ($player instanceof SGPlayer) {
				$sound = new PopSound($player->getPosition(), 0);
				$this->level->addSound($sound, [$player]);
			}
		}
	}

	/**
	 * cancel invincibility, inform players and update sign in lobby
	 */
	private function finishInvincibility() {
		foreach ($this->players as $player) {
			LbCore::getInstance()->alerts->postponeMessage($player);
			break;
		}
		$this->broadcastMessageLocalized("INVINCIBILITY_END");
		$this->invincible = false;
		foreach ($this->players as $player) {
			$sound = new PopSound($player->getPosition(), 0);
			$this->level->addSound($sound, [$player]);
		}
		$this->updateSign();
	}
	
	/**
	 * inform players about deathmatch countdown every minute
	 */
	private function deathMatchSoonNotify() {
		foreach ($this->players as $player) {
			LbCore::getInstance()->alerts->postponeMessage($player);
			break;
		}
		$minutesLeft = floor((self::DEATHMATCH_START_IN_SECONDS - $this->tick)/60);
		$minuteSuffix = ($minutesLeft > 1) ? "s" : "";
		foreach ($this->players as $player) {
			if ($player instanceof SGPlayer) {
				$player->sendLocalizedMessage("DEATHMATCH", array($minutesLeft, $minuteSuffix));
				$sound = new ClickSound($player->getPosition(), 2);
				$this->level->addSound($sound, [$player]);
			}
		}
	}

	/**
	 * calls in 5 seconds till deathmatch
	 * inform players, add sound
	 */
	private function deathMatchAlmostStartNotify() {
		foreach ($this->players as $player) {
			$secondsLeft = self::DEATHMATCH_START_IN_SECONDS - $this->tick;
			if ($player instanceof SGPlayer) {
				$player->sendLocalizedPopup("DM_COUNTDOWN", array($secondsLeft));
				$sound = new ClickSound($player->getPosition(), 1);
				$this->level->addSound($sound, [$player]);
			}
		}
	}
	
	/**
	 * Teleport players to deathmatch arena,
	 * inform them, update sign in lobby
	 */
	private function startDeathMatch() {
		foreach ($this->players as $player) {
			LbCore::getInstance()->alerts->postponeMessage($player);
			break;
		}
		$this->broadcastMessageLocalized("DEATHMATCH_START");
		foreach ($this->players as $player) {
			if ($player instanceof SGPlayer) {
                $player->setInDeathmatch(true);
				$player->teleport(new Vector3(
					rand($this->mapData['deathmatch'][0] - 4, $this->mapData['deathmatch'][0] + 4), 
					$this->mapData['deathmatch'][1] + 2, 
					rand($this->mapData['deathmatch'][2] - 4, $this->mapData['deathmatch'][2] + 4))
				);
			}
		}
		$this->deathmatch = true;
		$this->updateSign();
	}

	/**
	 * inform about end of deathmatch every minute
	 */
	private function deathMatchEndSoonNotify() {
		foreach ($this->players as $player) {
			LbCore::getInstance()->alerts->postponeMessage($player);
			break;
		}
		$minutesLeft = floor((self::MATCH_FINAL_IN_SECONDS - $this->tick)/60);
		$minuteSuffix = ($minutesLeft > 1) ? "s" : "";
		$this->broadcastMessageLocalized("ENDING", array($minutesLeft, $minuteSuffix));
	}
	
	/**
	 * Calls on adding player to tournament, some checks before allow player
	 * 
	 * @param SGPlayer $player
	 */
	public function addPlayer(SGPlayer $player) {
		//can't add player - game was started
		if ($this->started || $this->invincible) {
			$player->sendLocalizedMessage("ALREADY_STARTED", array(), "§1- §f");
			return false;
		}
		//locked account
		if ($player->isLocked()) {
			$player->sendLocalizedMessage("ACCOUNT_LOCKED", array(), "// ", " //");
			return false;
		}
		//needs login
		if ($player->isRegistered() && !$player->isAuthorized()) {
			$player->sendLocalizedMessage("NEEDS_LOGIN");
			return false;
		}
		//full arena
		if (count($this->players) >= self::MAX_PLAYER_COUNT) {
			$player->sendLocalizedMessage("FULL", array(), "§1- §f");
			return false;
		}
		//almost full arena and player is not vip
		if (count($this->players) >= self::MAX_NON_VIP_PLAYER_COUNT &&
				!$player->isVip()) {
			$player->sendLocalizedMessage("ALMOST_FULL", array(), "§1- §f");
			return false;
		}
		//accept player
		$this->acceptPlayer($player);
	}

	/**
	 * remove player from tournament, 
	 * unset him from tournament data, update sign,
	 * clear player's data
	 * 
	 * @param SGPlayer $player
	 * @param bool $fromWon
	 */
	public function removePlayer(SGPlayer $player, $fromWon = false) {
		if (isset($this->players[$player->getID()])) {
			unset($this->players[$player->getID()]);
			$player->setStateInLobby();
			$player->updateTournamentId(false);
			//clear inventory
			if ($player->getInventory() instanceof Inventory) {
				$player->getInventory()->clearAll();
				$player->getInventory()->sendContents($player);
			}
			//clear spawnpoint
			if (!$this->started) {
				foreach ($this->onSpawnPoint as $num => $point) {
					if ($point === $player->getName()) {
						unset($this->onSpawnPoint[$num]);
					}
				}
			}
			$this->removeFromTeam($player);
			$this->updateSign();
			//set winner if needs
			if (!$fromWon && $this->started) {
				$this->won();
			}
		}
	}

	/**
	 * Remove player info from team on current arena,
	 * clear player's team if he is not vip
	 * 
	 * @param SGPlayer $player
	 */
	private function removeFromTeam(SGPlayer $player) {
		if ($this->plugin->useTeams) {
			foreach ($this->teams as $color => $teamPlayers) {
				if (isset($teamPlayers[$player->getId()])) {
					unset($this->teams[$color][$player->getId()]);
					if (!$player->isVip()) {
						$player->setTeam(SGPlayer::DEFAULT_TEAM);
					}
					break;
				}
			}
		}
	}

	/**
	 * Calls in onPlayerDeath method to:
	 * remove dead player from tournament,
	 * inform survivors,
	 * increment kills counter for attacker
	 * 
	 * @param SGPlayer $player
	 * @param string $dm
	 */
	 
	public function removeDeadMan($player, $dm) {
		$this->removePlayer($player);
		//get attacker
		$attacker = false;
		$attackerEvent = $player->getLastDamageCause();
		if ($attackerEvent instanceof EntityDamageByEntityEvent) {
			$attacker = $attackerEvent->getDamager();
		}
		if ($this->started && !$this->invincible) {
			$players = $this->players;
			//inform survivors with sound
			foreach ($players as $p) {
				$sound = new BatSound($p->getPosition(), 2);
				$this->level->addSound($sound, [$p]);
			}
			if ($attacker instanceof Player) {
				//inform killed player
				$player->sendLocalizedMessage(
						"PLAYER_DEATH", array($player->getDisplayName(), $attacker->getDisplayName(), count($players)));
				//inform survivors on arena
				$this->broadcastMessageLocalized(
						"PLAYER_DEATH", array($player->getDisplayName(), $attacker->getDisplayName(), count($players)));
				//is first blood? say it
				if (count($this->kills) === 0) {
					$this->broadcastMessageLocalized(
							"FIRST_KILL", array($attacker->getDisplayName()));
				} else {//other congratulations
					$messages = array("SUCCESS_MSG_1", "SUCCESS_MSG_2", "SUCCESS_MSG_3", "SUCCESS_MSG_4");
					$message = $messages[rand(0, count($messages) - 1)];
					$this->broadcastMessageLocalized(
							$message, array($attacker->getDisplayName()));
				}
				$this->updateKillsCounter($attacker);
			} 
			
			//inform about number of survivors
			if (!$this->plugin->useTeams) {
				if (count($players) === 2) {
					$this->broadcastMessageLocalized("GOOD_LUCK_MSG");
				} elseif (count($players) > 2) {
					$this->broadcastMessageLocalized(
							"PLAYERS_REMAIN", array(count($players)));
				}
			}
			$this->won();//check for winner
		}
	}

	/**
	 * Update kills counter for player
	 * 
	 * @param SGPlayer $player
	 */
	private function updateKillsCounter(SGPlayer $player) {
		if (!$player->getTournamentId()) {
			return;
		}
		if (isset($this->kills[$player->getName()])) {
			$this->kills[$player->getName()] += 1;
		} else {
			$this->kills[$player->getName()] = 1;
		}
	}

	/**
	 * Localized broadcast message to show only inside arena
	 * 
	 * @param string $msg
	 * @param array $args
	 * @param string $prefix
	 * @param string $suffix
	 */
	private function broadcastMessageLocalized(
			string $msg, 
			array $args = array(), 
			string $prefix = "", 
			string $suffix = "") {
		foreach ($this->players as $player) {
			$player->sendLocalizedMessage($msg, $args, $prefix, $suffix);
		}
	}

	/**
	 * broadcast message without translate for all players in tournament
	 * 
	 * @param string $text
	 */
	private function broadcastMessage(string $text) {
		foreach ($this->players as $player) {
			if ($player instanceof SGPlayer) {
				$player->sendMessage($text);
			}
		}
	}

	/**
	 * calls when player join game:
	 * setup his inventory, teleport to pedestal, update info
	 * broadcast message inside arena, update tournament data and sign
	 * 
	 * @param SGPlayer $player
	 * @return boolean
	 */
	private function acceptPlayer(SGPlayer $player) {
		//operations with player
		$player->setupInventory();
		$this->teleportToPedestal($player);
		$this->addPlayerToTeam($player);
		$player->updateTournamentId($this->id);
		$player->setStateCountdown($this->id);
		$player->sendLocalizedPopup("JOINING", array(), "§1- §f");
		//update tournament info
		$this->broadcastMessageLocalized("ON_JOIN", array($player->getDisplayName()));
		$this->players[$player->getID()] = $player;
		$this->updateSign();
	}

	/**
	 * Look for team with less count of members,
	 * check if player has already have team 
	 * save player in tournament teams list and save team name in player's data
	 * 
	 * @param SGPlayer $player
	 */
	private function addPlayerToTeam(SGPlayer $player) {
		if ($this->plugin->useTeams) {
			//set team color			
			$targetTeamName = '';
			$targetTeamPlayersCount = PHP_INT_MAX;
			$minArray = array();
			if($targetTeamName == ''){
				foreach ($this->teams as $teamName => $teamPlayers) {
					$playersCount = count($teamPlayers);
					if ($playersCount < $targetTeamPlayersCount) {
						$minArray = array();
						$targetTeamPlayersCount = $playersCount;
						$minArray[$teamName] = $teamName;
					}
					if ($playersCount == $targetTeamPlayersCount) {
						$minArray[$teamName] = $teamName;
					}
				}
			}
			$targetTeamName = array_rand($minArray);
//			$teamColor = false;
//			foreach ($this->teams as $color => $teamPlayers) {
//				if (!$teamColor) {
//					$teamColor = $color;
//				} elseif (count($this->teams[$teamColor]) > count($teamPlayers)) {
//					$teamColor = $color;
//				}
//			}
			//set team if player is not in team
			if ($player->getTeam() === SGPlayer::DEFAULT_TEAM) {
				$player->setTeam($targetTeamName);
			} else {
				$targetTeamName = $player->getTeam();
			}
			$this->teams[$targetTeamName][$player->getId()] = $player;
		}
	}

	/**
	 * teleport player to empty pedestal on arena, send welcome message
	 * 
	 * @param SGPlayer $player
	 */
	private function teleportToPedestal(SGPlayer $player) {
		for ($i = 0; $i < self::PEDESTALS_COUNT; $i++) {
			if (!isset($this->onSpawnPoint[$i])) {
				$pedestal = $this->mapData['pedestals'][$i];
				$this->onSpawnPoint[$i] = $player->getName();
				$player->teleport(new Vector3($pedestal[0], $pedestal[1] + 2, $pedestal[2]));
				$player->extinguish();
				$player->sendMessage("----------------");
				$player->sendLocalizedMessage("TOURNAMENT_WELCOME", array($this->humanReadableTime));
				if ($this->id === self::MAP_OF_JUSTICE_ID) {
					$player->sendLocalizedMessage("JUSTICE_MAP_WELCOME");
				}
				$player->sendMessage("----------------");
				break;
			}
		}
	}
	

	/**
	 * Calls when smb (player or team) win tournament
	 * $candidate is a color of won team
	 * 
	 */
	private function won() {
		if (count($this->players) == 0) {
			$this->restart();
			return;
		}
		$winners = array();
		$candidate = false;
		//look for winner player or team
		if ($this->plugin->useTeams) {
			foreach ($this->teams as $color => $team) {
				if (count($team) > 0) {
					if ($candidate) {
						$candidate = false;
						break;
					} else {
						$candidate = $color;
					}
				}
			}
			if ($candidate) {
				$winners = $this->teams[$candidate];
			}
		} else {
			if (count($this->players) === 1) {
				foreach ($this->players as $p) {
					$candidate = $p->getName();
				}
				$winners = $this->players;
			}
		}
		if ($candidate) {
			$winnername = ucfirst($candidate);
			foreach ($winners as $winner) {
				if ($winner instanceof Player) {
					//update settings for winner
					$winner->setHealth(20);
					$winner->setFood(20);
					$winner->teleport($this->plugin->getServer()->getDefaultLevel()->getSpawnLocation());
					$winner->setSpawnOptions();
					$this->removePlayer($winner, true);
				}
				//messages for winners
				$winner->sendMessage("> -----------------------------");
				$winner->sendLocalizedMessage("WON_MATCH", array($winnername));
				$winner->sendMessage("> -----------------------------");
			}
			//and send messages to all players in lobby
			foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
				if (!$p->getTournamentId()) {
					$p->sendLocalizedMessage("WON_MATCH_BROADCAST", array($winnername, $this->id));
				}
			}
			$this->restart();
		}
	}
	
	/**
	 * calls in tournament construct to set first signs
	 */
	private function initSigns() {
		$this->setSign(1, PluginData::$defaultSignData[0]);
		$this->setSign(2, PluginData::$defaultSignData[1]);
		$this->setSign(3, PluginData::$defaultSignData[2]);
		$this->setSign(4, PluginData::$defaultSignData[3]);
		$this->setSign(5, PluginData::$defaultSignData[4]);
	}

	/**
	 * method calls when tournament status changes,
	 * update sign in lobby
	 */
	private function updateSign() {
		$gameStatus = TextFormat::DARK_PURPLE . "Running";
		$playerCount = TextFormat::DARK_AQUA . 	" | " . TextFormat::DARK_BLUE . $this->getPlayerCount();
		$maxPlayerCount = "/24";
		if (!$this->started) {
			//joinable for all players
			if ($this->getPlayerCount() < self::MAX_NON_VIP_PLAYER_COUNT) {
				$gameStatus = TextFormat::GREEN . "Join";
				//only for VIPs
			} elseif ($this->getPlayerCount() < self::MAX_PLAYER_COUNT) {
				$gameStatus = TextFormat::GOLD . "VIP";
			} else {//full arena
				$gameStatus = TextFormat::RED . "Full";
				$playerCount = TextFormat::WHITE . self::MAX_PLAYER_COUNT;
			}
		} elseif ($this->invincible) {//invincible - time of Grace
			$gameStatus = TextFormat::DARK_PURPLE . "Grace";
		} elseif ($this->deathMatch) {//deathmatch started
			$gameStatus = TextFormat::RED . "DM";		
		} else {//running game
			$maxPlayerCount = TextFormat::DARK_BLUE . "/" . TextFormat::DARK_BLUE . "24";
		}		
		$mapStat = TextFormat::DARK_GRAY . "[" . $gameStatus . TextFormat::DARK_GRAY . "]" . 
					$playerCount . $maxPlayerCount;		
		$this->setSign($this->id, array(
									$mapStat,
									TextFormat::DARK_AQUA . PluginData::$mapNames[$this->mapId],
									TextFormat::YELLOW . "SG-" . $this->id,
									""
									));
	}
	
	/**
	 * set one sign, mostly used in updateSign method to change info on sign,
	 * there are all sign coords here
	 * 
	 * @param number $id
	 * @param array $text
	 */
	private function setSign($id, array $text) {
		$lobby = $this->plugin->getServer()->getDefaultLevel();
		if (!$lobby instanceof Level) {
			return false;
		}
		$tile = null;
		if (!empty(PluginData::$mapSignCoords[$id])) {
			$tile = $lobby->getTile(new Vector3(
					PluginData::$mapSignCoords[$id][0],
					PluginData::$mapSignCoords[$id][1],
					PluginData::$mapSignCoords[$id][2]));
		}
		if ($tile) {
			$tile->setText($text[0], $text[1], $text[2], $text[3]);
		}
	}
	

}
