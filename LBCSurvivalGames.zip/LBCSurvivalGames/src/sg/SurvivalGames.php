<?php

namespace sg;

use LbCore\language\Translate;
use GametypeStatues\GametypeStatues;
use VipLounge\VIPLounge;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use Kits\Kit;
use pocketmine\math\Vector3;

/**
 * Base plugin class, contains onEnable and onDisable methods,
 * specific SG commands like /lobby, /lbtime,
 * setSpawnOptions - method sets common spawn options for player
 * won - works when player won game
 * 
 */
class SurvivalGames extends PluginBase {
	/*@var int*/
	private $lastMapUsed = 1;
	/*@var string*/
	private $translatePath = 'sg\\language\\';
	/*@var array*/
	public $tournaments = array();
	/*@var bool*/
	public $useTeams = false; //set true to change gamemode to Teams
	/**@var bool*/
	public $testing = false;//set options for easy testing (ex: play alone in tournament)

	/**
	 * @return int
	 */
	public function getLastMapUsed() {
		return $this->lastMapUsed;
	}
	
	/**
	 * @param int $value
	 */
	public function setLastMapUsed($value) {
		$this->lastMapUsed = $value;
	}

	/**
	 * calls when plugin enable
	 * 
	 */
	public function onEnable() {
		$this->getLogger()->info("Starting Lifeboat Survival Games Server...");
		//upload listener
		$listener = new EventListener($this);
		$this->getServer()->getPluginManager()->registerEvents($listener, $this);
		$this->getServer()->getDefaultLevel()->setTime(6000);
		$this->getServer()->getDefaultLevel()->stopTime();
        $this->getServer()->getDefaultLevel()->setSpawnLocation(new Vector3(-10, 38, -22));
		//create translates
		Translate::getInstance()->createTranslations($this->translatePath);
		//setup first tournament
		$this->getLogger()->info("Setting up a tournament...");
		$this->tournaments[1] = new Tournament($this);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new task\TournamentTick($this), 10);
		//set plugin name
		$pluginName = ($this->useTeams) ? "Teams" : "SG";
		$this->getServer()->getNetwork()->setName(
				TextFormat::AQUA . "Life" . TextFormat::RED . "Boat " . 
				TextFormat::BOLD . TextFormat::GOLD . $pluginName);
		//init lobby statues
		GametypeStatues::getInstance()->enable("SurvivalGames");
		//enable VIPLounge
		try {
			VIPLounge::enable($this);
			VIPLounge::getInstance()->initLoungeGuards();
		} catch (Exception $e) {
			echo 'EXCEPTION: Problem with starting VIPLounge' . PHP_EOL;
			echo 'EXCEPTION: ' . $e->getMessage() . PHP_EOL;
		}
		// enable kits
		Kit::enable($this);
		//enable pets
		$this->getServer()->getPluginManager()->registerEvents(new \Pets\PetsManager($this), $this);
		$this->getLogger()->info("Done!");

	}

	/**
	 * calls when plugin disable, nothing here for now
	 */
	public function onDisable() {
		//
	}
	
	
	/**
	 * specific SG commands handling:
	 * 1. /lobby - return from arena to lobby
	 * 2. /lbtime - show time left in tournament countdown
	 * 
	 * @param CommandSender $sender
	 * @param Command $command
	 * @param $label
	 * @param array $args
	 * @return bool
	 */
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
		$name = $command->getName();
		switch ($name) {
			case "lobby":
				$sender->sendLocalizedMessage("RETURN_TO_LOBBY");
				if ($sender->getTournamentId()) {
					$this->tournaments[$sender->getTournamentId()]->removePlayer($sender);
				}
				$sender->setSpawnOptions();
                $sender->setStateInLobby();
				$sender->teleport($this->getServer()->getDefaultLevel()->getSpawnLocation());
				break;

			case "lbtime":
				if (!$sender->getTournamentId()) {
					$sender->sendLocalizedMessage("LBTIME_ERROR");
				} else {
					$tournament = $this->tournaments[$sender->getTournamentId()];
					$sender->sendLocalizedMessage("SHOW_LBTIME", array($tournament->getCountdownTime()));
				}
				break;
		}
		return true;
	}


	/**
	 * Function for lbcore alerts
	 * 
	 * @param int  $arenaId
	 * @return bool
	 */
	public function getCensus($arenaId) {
		$status = "";
		if (isset($this->tournaments[$arenaId])) {
			if ($this->useTeams) {
				$currentTeams = $this->tournaments[$arenaId]->getTeams();
				foreach ($currentTeams as $color => $members) {
					if ($status != "") {
						$status .= ", ";
					}
					$status .= count($members) . " " . ucfirst($color);
				}
				return "Players in arena: " . $status;
			} else {
				return $this->tournaments[$arenaId]->getPlayerCount() . " players in arena";
			}
		}
		return false;
	}

}
