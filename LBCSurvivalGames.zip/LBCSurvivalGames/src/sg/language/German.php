<?php
namespace sg\language;

use pocketmine\utils\TextFormat;
use LbCore\language\core\German as LbGerman;

/**
 * Class contains specific plugin translates, 
 * add them into parent LbCore array $translates
 */
class German extends LbGerman {

	public function __construct() {
		$this->translates["ALREADY_STARTED"] = "§dDieser Wettkampf hat bereits gestartet.";
		$this->translates["TOURNAMENT_STOPPED"] = "§1- §dDieser Server ist nicht am laufen.";
		$this->translates["ALMOST_FULL"] = "§1- §7 Dieser Wettkampf ist nur noch für §6VIP§7s,\n§1- §7da es fast voll ist.";
		$this->translates["FULL"] = "§dDieser Wettkampf ist voll.";
		$this->translates["WON_MATCH"] = "§9> §farg1 §6hat das Match gewonnen.\n§9> §7Kehre zur Lobby zurück...";
		$this->translates["WON_MATCH_BROADCAST"] = "§aarg1 hat das Match auf SG-arg2 gewonnen.";
		$this->translates["PLAYER_DEATH"] = "§barg1 §3wurde von §farg2§3 getötet. §barg3 §3Überlebende verbleibend.";
		$this->translates["GOOD_LUCK_MSG"] = "Zwei Spieler verbleibend, viel Glück!";
		$this->translates["FIRST_KILL"] = "§aarg1 §5hat den ersten Kill bekommen!";
		$this->translates["SUCCESS_MSG_1"] = "§aarg1 räumt auf!";
		$this->translates["SUCCESS_MSG_2"] = "§aarg1 §r§aist am §9#gewinnen§a!";
		$this->translates["SUCCESS_MSG_3"] = "§aarg1 macht einen Amoklauf!";
		$this->translates["SUCCESS_MSG_4"] = "§aarg1 hat eine Glückssträhne!";
		$this->translates["MATCH_RESTARTING"] = "§9>§7 Wettkampf beendet. Danke fürs spielen!\n> Starte Server neu...";
		$this->translates["STARTING_IN"] = "§9> §7Spiel startet in: §farg1§7.";
		$this->translates["TOURNAMENT_START"] = "§9> §6Der Wettkampf hat begonnen!";
		$this->translates["USING_MAP"] = "§9> §bBenutze Map: arg1";
		$this->translates["USING_MAP_CREATOR"] = "§9>§7 Benutze Map: arg1 von arg2";
		$this->translates["INVINCIBILITY_30"] = "§9> §3Du hast noch §edreißig§3 Sekunden Unsterblichkeit.";
		$this->translates["INVINCIBILITY_15"] = "§9> §3Du hast noch §efünfzehn§3 Sekunden Unsterblichkeit.";
		$this->translates["INVINCIBILITY_END"] = "§9> §3Du bist nicht mehr unbesiegbar.";
		$this->translates["CHEST_REFILL"] = "§9> §eAlle Kisten wurden neu gefüllt!";
		$this->translates["DEATHMATCH_START"] = "§9>§7 Willkommen zum Deathmatch. Soll der beste Spieler gewinnen!";
		$this->translates["STARTING"] = "§9> §3Starte in §earg1§3...";
		$this->translates["DEATHMATCH"] = "§9> §3Deathmatch startet in §earg1§3 Minute(n).";
		$this->translates["DM_COUNTDOWN"] = "§9> §3Deathmatch startet in §earg1§3...";
		$this->translates["ENDING"] = "§9> §3Wettkampf endet in §earg1§3 Minute(n).";
		$this->translates["JOINING"] = "§bBetrete das Match...";
		$this->translates["TOURNAMENT_WELCOME"] = "§bWillkommen zum Wettkampf!\n§bEr startet in §3arg1§b.";
		$this->translates["ON_JOIN"] = "§9>§f arg1 §ehat das Match betreten.";
		$this->translates["PLAYERS_REMAIN"] = "arg1 Spieler verbleibend.";
		$this->translates["RETURN_TO_LOBBY"] = "§1- §7Kehre zur Lobby zurück.";
		$this->translates["LBTIME_ERROR"] = "§1- §7Betrete vorher einen Wettkampf.";
		$this->translates["SHOW_LBTIME"] = "§1- §7Der Wettkampf startet in arg1.";
		$this->translates["ONLY_FOR_VIP"] = "§cDiese Aktion ist nur für VIPs.\n§cDu kannst den VIP Rang in der Lifeboat+ App kaufen.";
		$this->translates["TEAM_CHANGED"] = "§6Dein Team wurde erfolgreich geändert!\n§6Dein jetziges Team ist arg1";
		$this->translates["JUSTICE_MAP_WELCOME"] = TextFormat::GOLD . "Kits sind auf dieser Karte deaktiviert.\n" 
				. TextFormat::GOLD . "Also, Sie bekommen keine Waffe, Rüstung oder spezielle Fähigkeiten.\n"
				. TextFormat::GOLD . "Scary!";
	}
}